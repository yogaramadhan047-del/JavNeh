JAVNEH.COM — STATIC SITEMAP

File location in the Next.js repository:
  public/sitemap.xml

IMPORTANT:
The current project uses app/sitemap.ts to serve the same /sitemap.xml route.
Before adding public/sitemap.xml, remove app/sitemap.ts (or move it outside the app
routing tree) to avoid a route conflict/build error. Make this change in the same
GitHub commit as adding public/sitemap.xml.

This static snapshot contains the 83 unique URLs present in the sitemap downloaded
from https://javneh.com/sitemap.xml on 2026-10-12. New movies/articles will NOT
automatically appear in this static file; it must be refreshed when content changes.

After deployment, check:
  https://javneh.com/sitemap.xml
Then submit only that URL in Google Search Console.

Note: the XML was validated for well-formedness and duplicate URLs. A successful
deployment does not guarantee Google Search Console will immediately accept it.
